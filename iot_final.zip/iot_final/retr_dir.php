<?php
$con=mysqli_connect("localhost","saalim","password","iot");
$response = array();
if (mysqli_connect_errno($con))
{
   echo '{"query_result":"ERROR"}';
}
 

 
$result = mysqli_query($con,"SELECT * FROM `scene` ");
 
$res = array();
if ($result->num_rows > 0) {
 
     while($row = mysqli_fetch_array($result)){
$rt = mysqli_query($con,"SELECT * FROM `mapping` WHERE `mapping`.`id` ='$row[1]'");
while($row2 = mysqli_fetch_array($rt)){
			array_push($res,
array('device_name'=>$row[0],
'name'=>$row2[0],
'id'=>$row[1],
'attr'=>$row[2],
'value'=>$row[3],
));
		}

}
    echo json_encode(array("result"=>$res)); 
} else {
    
 
    // echo no users JSON
     echo '{"query_result":"FAILURE"}';
    
}
mysqli_close($con);
?>
