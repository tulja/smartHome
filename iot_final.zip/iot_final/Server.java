import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
 
public class Server
{
 
    private static Socket socket;
 
    public static void main(String[] args)
    {
        try
        {
            int port = 25000;
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server Started and listening to the port 25000");
 
            //Server is running always. This is done using this while(true) loop
            while(true)
            {
                //Reading the message from the client

                socket = serverSocket.accept();
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String number = br.readLine();
		String hu[] = number.split(" ");
                System.out.println("Message received from client is "+number);
                int num = Integer.parseInt(hu[0]);
		Process ps;
		Runtime rt = Runtime.getRuntime();
		if(num==800){
			String vy = "./sct.sh "+num+" "+hu[1];
			ps = rt.exec(vy);
           		ps.waitFor();
		}else if(num==900){
			String vy = "./sct.sh "+num+" "+hu[1];
			ps = rt.exec(vy);
            		ps.waitFor();
		}else{
 			String vy = "./sct.sh "+num+" "+"0";
 			ps = rt.exec(vy);
           		ps.waitFor();
		}

            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                socket.close();
            }
            catch(Exception e){}
        }
    }
}
