tmux new -d -s scene1 "./sceneserver $1 $2"
