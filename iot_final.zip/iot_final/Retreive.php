<?php
$con=mysqli_connect("localhost","saalim","password","iot");
$response = array();
if (mysqli_connect_errno($con))
{
   echo '{"query_result":"ERROR"}';
}
 
$mac1 = $_GET['mac1'];
$mac2 = $_GET['mac2'];
$mac3 = $_GET['mac3'];
$mac4 = $_GET['mac4']; 
$result = mysqli_query($con,"SELECT * FROM `mapping` WHERE `mapping`.`scene_name` ='$mac4'");
if($result->num_rows>0){
     echo '{"query_result":"FAILURE"}';
} else{
	$rt = mysqli_query($con,"INSERT INTO `mapping`(scene_name) VALUES('$mac4')");
	if($rt==false){
		echo '{"query_result":"Map_fail"}';	
	}
	$st = mysqli_query($con,"SELECT * FROM `mapping` WHERE `mapping`.`scene_name` ='$mac4'");
	if ($st->num_rows > 0) {
 
     		while($row = mysqli_fetch_array($st)){
			$yt =  mysqli_query($con,"INSERT INTO `scene` VALUES('$mac1','$row[1]','$mac2','$mac3')");
			if($yt==false){
				echo '{"query_result":"Scene_fail"}';
			}else{
				echo '{"query_result":"SUCCESS"}';
			}
		}
		
    	 
	} 
	
}
mysqli_close($con);
?>
