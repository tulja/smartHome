<?php
$con=mysqli_connect("localhost","saalim","password","iot");
$response = array();
if (mysqli_connect_errno($con))
{
   echo '{"query_result":"ERROR"}';
}
 
$mac1 = $_GET['mac1'];
$mac2 = $_GET['mac2'];
$mac3 = $_GET['mac3'];
$result = mysqli_query($con,"SELECT * FROM `mapping` WHERE `mapping`.`scene_name` ='$mac1'");

if($result->num_rows>0){
     while($row = mysqli_fetch_array($result)){
			$yt =  mysqli_query($con,"DELETE FROM `scene` WHERE `scene`.`scene_id`='$row[1]'");
			$ry = mysqli_query($con,"DELETE FROM `mapping` WHERE `mapping`.`scene_name` ='$mac1'");
			if($yt==false){
				echo '{"query_result":"Scene_fail"}';
			}else{
				echo '{"query_result":"SUCCESS"}';
			}
		}
} 
mysqli_close($con);
?>
