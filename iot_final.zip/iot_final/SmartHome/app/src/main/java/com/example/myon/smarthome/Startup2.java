package com.example.myon.smarthome;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by saalim on 6/5/17.
 */

public class Startup2 extends Activity {
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.startup2);
        new Retreive2(Startup2.this).execute();
    }
    class Retreive2 extends AsyncTask<String, Integer, String> {
        private Activity context;
        private int c = 0;
        //Startup obj ;
        int flag=0;
        public Retreive2(Activity context) {
            this.context = context;
        }
        @Override
        protected String doInBackground(String... arg0) {

            String link;
            String data;
            BufferedReader bufferedReader;
            try {

                link = "http://192.168.136.87/retr_dir.php";
                URL url = new URL(link);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();

                bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();

                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                result = sb.toString();
                flag=1;
                return result;
            } catch (Exception e) {

                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {

            String jsonStr = result;
            //showList(jsonStr);

            if(flag==1) {
                Intent i = new Intent(context, MainActivity.class);
                //List<varr> li = Arrays.asList(v);
                //ArrayList<varr> vi = new ArrayList<varr>(li);
                i.putExtra("key", result);
                context.finish();
                context.startActivity(i);
            }else{
                Toast.makeText(context.getApplicationContext(),"Unable to connect ...Please check your connection", Toast.LENGTH_SHORT).show();
            }
        }


    }
}
