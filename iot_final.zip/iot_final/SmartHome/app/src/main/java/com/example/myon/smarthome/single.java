package com.example.myon.smarthome;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;

/**
 * Created by saalim on 3/12/17.
 */

public class single extends AppCompatActivity implements View.OnClickListener {
    TextView t;
    EditText et;
    Button b;
    String ident ="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_scene);
        Intent i = getIntent();
        String att = i.getStringExtra("attr");
        String val = i.getStringExtra("val");
        if(att.contentEquals("Speed")) {
            ident += "800";
        }else {
            ident += "900";
        }

        t = (TextView)findViewById(R.id.textView);
        et = (EditText)findViewById(R.id.et5);
        t.setText(att);
        et.setHint(val);
        b = (Button)findViewById(R.id.button2);
        b.setOnClickListener(this);

        //tv.setOnClickListener(buttonSendOnClickListener2);
    }

    @Override
    public void onClick(View view) {
        String vp = et.getText().toString();
        ident+=" "+vp;
        Socket socket = null;
        DataOutputStream dataOutputStream = null;
        DataInputStream dataInputStream = null;
        ///////////
        try {
            String host = "localhost";
            int port = 25000;
            InetAddress address = InetAddress.getByName(host);
            socket = new Socket("10.42.0.1", 25000);

            //Send the message to the server
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);

            //String number = "10";
            Log.i("Button", "2");

            String sendMessage = ident + "\n";
            bw.write(sendMessage);
            bw.flush();
            System.out.println("Message sent to the server : " + sendMessage);

            //Get the return message from the server
                        /*InputStream is = socket.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);
                        BufferedReader br = new BufferedReader(isr);
                        String message = br.readLine();
                        System.out.println("Message received from the server : " +message);
                        textIn.setText(message);*/
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            //Closing the socket
            try {
                socket.close();
                et.setText("");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    }


