package com.example.myon.smarthome;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by saalim on 4/12/17.
 */

public class delete extends AppCompatActivity implements View.OnClickListener{
    Button b;
    EditText et;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete);
        b=(Button)findViewById(R.id.button9);
        et = (EditText)findViewById(R.id.editText8);
        b.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        new Retreive2(delete.this).execute(et.getText().toString(),et.getText().toString(),et.getText().toString());
    }
    class Retreive2 extends AsyncTask<String, Void, String> {
        private Context context;
        private int c = 0;
        int fh = 0;

        public Retreive2(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            // SHOW THE SPINNER WHILE LOADING FEEDS

            // linlaHeaderProgress.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... arg0) {
            final String mac1 = arg0[0];
            String mac2 = arg0[1];
            String mac3 = arg0[2];
            String link;
            String data;
            BufferedReader bufferedReader;
            String result;
            try {

                data = "?mac1=" + URLEncoder.encode(mac1, "UTF-8");
                data += "&mac2=" + URLEncoder.encode(mac2, "UTF-8");
                data += "&mac3=" + URLEncoder.encode(mac3, "UTF-8");
                // Toast.makeText(context, "Data could not be inserted. Signup failed.", Toast.LENGTH_SHORT).show();
                link = "http://192.168.136.87/signup.php"+data;
                URL url = new URL(link);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();

                bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();

                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                result = sb.toString();
                fh = 1;
                return result;
            } catch (Exception e) {

                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {

            String jsonStr = result;

            //linlaHeaderProgress.setVisibility(View.GONE);
            if (fh == 1) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    String res = jsonObj.getString("query_result");
                    Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(getApplicationContext(),result, Toast.LENGTH_SHORT).show();
            }
            et.setText("");
        }
    }
}
