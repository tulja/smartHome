package com.example.myon.smarthome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by saalim on 7/11/17.
 */

public class create extends AppCompatActivity implements
        OnItemSelectedListener,View.OnClickListener {
    Spinner s1, s2;
    int val;
    AlertDialog.Builder builder;
    EditText et, et3;
    Button b1;
    String sp1_c, sp2_c;
    String dev="", attr="", value="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create);
        s1 = (Spinner) findViewById(R.id.spinner1);
        s2 = (Spinner) findViewById(R.id.spinner2);
        s1.setOnItemSelectedListener(this);
        et = (EditText) findViewById(R.id.et1);
        et3 = (EditText) findViewById(R.id.et2);
        b1 = (Button) findViewById(R.id.button);
        b1.setOnClickListener(this);
        builder = new AlertDialog.Builder(this);
        //tv.setOnClickListener(buttonSendOnClickListener2);
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                               long arg3) {
        // TODO Auto-generated method stub
        String sp1 = String.valueOf(s1.getSelectedItem());
        if (sp1.contentEquals("Fan")) {
            sp1_c = "fan";
            //Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
            List<String> list = new ArrayList<String>();
            list.add("Speed");
            et.setHint("Integer");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter.notifyDataSetChanged();
            s2.setAdapter(dataAdapter);

        }
        if (sp1.contentEquals("Light")) {
            sp1_c = "light";
           // Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
            List<String> list = new ArrayList<String>();
            list.add("Power");
            et.setHint("ON/OFF");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        String sp2 = String.valueOf(s2.getSelectedItem());
        attr=attr+" "+sp2.toLowerCase();

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onClick(View view) {
        builder.setMessage("Add More Devices(Please keep Scene Name same)").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dev=dev+" "+sp1_c;
                value=value+" "+et.getText().toString().toLowerCase();
                et.setText("");
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dev=dev+" "+sp1_c;
                value=value+" "+et.getText().toString().toLowerCase();
                new Retreive_data(getApplicationContext()).execute(dev,
                        attr, value, et3.getText().toString().toLowerCase());
                finish();
            }
        });

        AlertDialog alert = builder.create();
        alert.setTitle("Info");
        alert.show();
    }

    class Retreive_data extends AsyncTask<String, Void, String> {
        private Context context;
        private int c = 0;
        int fh = 0;

        public Retreive_data(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            // SHOW THE SPINNER WHILE LOADING FEEDS

            // linlaHeaderProgress.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... arg0) {
            final String mac1 = arg0[0];
            String mac2 = arg0[1];
            String mac3 = arg0[2];
            String mac4 = arg0[3];
            String link;
            String data;
            BufferedReader bufferedReader;
            String result;
            try {

                data = "?mac1=" + URLEncoder.encode(mac1, "UTF-8");
                data += "&mac2=" + URLEncoder.encode(mac2, "UTF-8");
                data += "&mac3=" + URLEncoder.encode(mac3, "UTF-8");
                data += "&mac4=" + URLEncoder.encode(mac4, "UTF-8");
                // Toast.makeText(context, "Data could not be inserted. Signup failed.", Toast.LENGTH_SHORT).show();
                link = "http://192.168.136.87/Retreive.php" + data;
                URL url = new URL(link);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();

                bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();

                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                result = sb.toString();
                fh = 1;
                return result;
            } catch (Exception e) {

                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {

            String jsonStr = result;

            //linlaHeaderProgress.setVisibility(View.GONE);
            if (fh == 1) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    String res = jsonObj.getString("query_result");
                    Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Unable to Create", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
