package com.example.myon.smarthome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.StrictMode;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener {

    EditText textOut;
    TextView textIn;
    NDSpinner s2, s3;
    Button bb;
    AlertDialog.Builder builder2,builder3;
    ArrayList arr[];
    String result;
    int yy = 0;
    int pp = 0;
    Map<String, Integer> mp;
    int num_scene = 0;
    private List<String> List_file;
    int ids[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        builder2 = new AlertDialog.Builder(this);
        builder3 = new AlertDialog.Builder(this);
        s2 = (NDSpinner) findViewById(R.id.spinner3);
        s2.setOnItemSelectedListener(this);
        s3 = (NDSpinner) findViewById(R.id.spinner4);
        s3.setOnItemSelectedListener(this);
        bb = (Button) findViewById(R.id.button6);
        bb.setOnClickListener(this);
        Intent i = getIntent();
        List_file = new ArrayList<String>();
        String res = i.getStringExtra("key");
        //Toast.makeText(getApplicationContext(),res,Toast.LENGTH_LONG).show();
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        JSONObject jsonObj = null;
        try {
            jsonObj = new JSONObject(res);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JSONArray peoples = null;
        mp = new HashMap<String, Integer>();
        try {
            peoples = jsonObj.getJSONArray("result");
            num_scene = peoples.length();
            arr = new ArrayList[1000];
            ids = new int[1000];
            mp = new HashMap<String, Integer>();
            for (int ii = 0; ii < peoples.length(); ii++) {
                JSONObject c = peoples.getJSONObject(ii);
                String ssid = c.getString("device_name").toLowerCase();
                String id = c.getString("name");
                int ind = c.getInt("id");
                ids[ii] = ind;
                if (!mp.containsKey(id)) {
                    mp.put(id, ii);
                }
                String rssi = c.getString("attr").trim();
                //int room = Integer.parseInt(c.getString("length").trim());
                String snr = c.getString("value");
                arr[ii] = new ArrayList();
                arr[ii].add(ssid);
                arr[ii].add(rssi);
                arr[ii].add(snr);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // textOut = (EditText)findViewById(R.id.textout);
        for (Map.Entry<String, Integer> entry : mp.entrySet()) {
            List_file.add(entry.getKey());
        }
        List<String> li = new ArrayList<String>();
        li.add("fan");
        li.add("light");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, List_file);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dataAdapter.notifyDataSetChanged();
        s2.setAdapter(dataAdapter);
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, li);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dataAdapter2.notifyDataSetChanged();
        s3.setAdapter(dataAdapter2);
        textIn = (TextView) findViewById(R.id.textin);

        //list = (ListView)findViewById(R.id.listview);

        // CreateListView();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.newmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id) {
            case R.id.new1:
                Intent i = new Intent(getApplicationContext(), device.class);
                startActivity(i);
                break;
            case R.id.save:
                i = new Intent(getApplicationContext(), create.class);
                startActivity(i);
                break;
            case R.id.delete:
                i = new Intent(getApplicationContext(), delete.class);
                startActivity(i);
                break;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        switch (adapterView.getId()) {
            case R.id.spinner4:
                String text = s3.getSelectedItem().toString();
                pp++;
                if (pp > 1) {
                    if (text.contentEquals("fan")) {
                        Intent ll = new Intent(getApplicationContext(), single.class);
                        ll.putExtra("attr", "Speed");
                        ll.putExtra("val", "Integer");
                        startActivity(ll);
                    } else {
                        Intent ll = new Intent(getApplicationContext(), single.class);
                        ll.putExtra("attr", "Power");
                        ll.putExtra("val", "On/Off");
                        startActivity(ll);
                    }
                }
                break;
            case R.id.spinner3:
                final int ind = mp.get(s2.getSelectedItem());
                yy++;
                if (yy > 1) {
                    builder2 = new AlertDialog.Builder(this);
                    builder2.setMessage(arr[ind].toString()).setPositiveButton("Execute Scene", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //int ind = s2.getSelectedItemPosition();
                            Socket socket = null;
                            DataOutputStream dataOutputStream = null;
                            DataInputStream dataInputStream = null;
                            ///////////
                            try {
                                String host = "localhost";
                                int port = 25000;
                                InetAddress address = InetAddress.getByName(host);
                                socket = new Socket("10.42.0.1", 25000);

                                //Send the message to the server
                                OutputStream os = socket.getOutputStream();
                                OutputStreamWriter osw = new OutputStreamWriter(os);
                                BufferedWriter bw = new BufferedWriter(osw);

                                //String number = "10";
                                Log.i("Button", "2");

                                String sendMessage = String.valueOf(ids[ind]) + "\n";
                                bw.write(sendMessage);
                                bw.flush();
                                System.out.println("Message sent to the server : " + sendMessage);

                                //Get the return message from the server
                        /*InputStream is = socket.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);
                        BufferedReader br = new BufferedReader(isr);
                        String message = br.readLine();
                        System.out.println("Message received from the server : " +message);
                        textIn.setText(message);*/
                            } catch (Exception exception) {
                                exception.printStackTrace();
                            } finally {
                                //Closing the socket
                                try {
                                    socket.close();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog alert = builder2.create();
                    alert.setTitle("Info");
                    alert.show();
                }

                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onClick(View view) {
        new Retreive2(MainActivity.this).execute();

    }

    class Retreive2 extends AsyncTask<String, Integer, String> {
        private Activity context;
        private int c = 0;
        //Startup obj ;
        int flag = 0;

        public Retreive2(Activity context) {
            this.context = context;
        }

        @Override
        protected String doInBackground(String... arg0) {

            String link;
            String data;
            BufferedReader bufferedReader;
            try {

                link = "http://192.168.136.87/retr_dir.php";
                URL url = new URL(link);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();

                bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();

                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                result = sb.toString();
                flag = 1;
                return result;
            } catch (Exception e) {

                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {

            String jsonStr = result;
            //showList(jsonStr);

            if (flag == 1) {
                JSONObject jsonObj = null;
                try {
                    jsonObj = new JSONObject(result);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                JSONArray peoples = null;
                mp = new HashMap<String, Integer>();
                try {
                    peoples = jsonObj.getJSONArray("result");
                    num_scene = peoples.length();
                    arr = new ArrayList[1000];
                    ids = new int[1000];
                    mp = new HashMap<String, Integer>();
                    for (int ii = 0; ii < peoples.length(); ii++) {
                        JSONObject c = peoples.getJSONObject(ii);
                        String ssid = c.getString("device_name").toLowerCase();
                        String id = c.getString("name");
                        int ind = c.getInt("id");
                        ids[ii] = ind;
                        if (!mp.containsKey(id)) {
                            mp.put(id, ii);
                        }
                        String rssi = c.getString("attr").trim();
                        //int room = Integer.parseInt(c.getString("length").trim());
                        String snr = c.getString("value");
                        arr[ii] = new ArrayList();
                        arr[ii].add(ssid);
                        arr[ii].add(rssi);
                        arr[ii].add(snr);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                List_file = new ArrayList<>();
                // textOut = (EditText)findViewById(R.id.textout);
                for (Map.Entry<String, Integer> entry : mp.entrySet()) {
                    List_file.add(entry.getKey());
                }
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(MainActivity.this,
                        android.R.layout.simple_spinner_item, List_file);
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                dataAdapter.notifyDataSetChanged();
                yy=0;
                s2.setAdapter(dataAdapter);
            } else {
                Toast.makeText(getApplicationContext(), "Unable to connect ...Please check your connection", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
